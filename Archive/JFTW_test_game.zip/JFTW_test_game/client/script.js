var game;

window.onload = function() {
    var el = document.getElementById("canvas");
    game = new Game(el);
    game.load();
};
