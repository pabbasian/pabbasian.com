package processing.test.snake_android;enum Direction
{
    UP,RIGHT,LEFT,DOWN
};