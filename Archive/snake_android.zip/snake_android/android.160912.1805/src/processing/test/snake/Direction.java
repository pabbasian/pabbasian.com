package processing.test.snake;enum Direction
{
    UP,RIGHT,LEFT,DOWN
};