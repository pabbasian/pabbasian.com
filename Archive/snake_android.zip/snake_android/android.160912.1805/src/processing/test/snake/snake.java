package processing.test.snake;

import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class snake extends PApplet {


int x, y = 0;
Cell[][] grid;

// Number of columns and rows in the grid
int cols = 50;
int rows = 50;
PFont myFont;
int _counter =20;
int _delay =5;
Direction d=Direction.RIGHT;
public void setup() {
  
  x=25;
  y=25;
  cols = width/10;
  rows = height/10;

  frameRate(16);
  //  myFont = createFont("Arial", 32);
  myFont = loadFont("Phosphate-Inline-48.vlw");

  grid = new Cell[cols][rows];
  //snake = new Cell[100];
  for (int i = 0; i < cols; i++) {
    for (int j = 0; j < rows; j++) {
      // Initialize each object
      grid[i][j] = new Cell(i*10, j*10, 10, 10, i+j);
    }
  }
}

public void doDirection() {
  switch (d) {
  case UP: 
    y--;
    break;
  case RIGHT: 
    x++;
    break;
  case DOWN: 
    y++;
    break;
  case LEFT: 
    x--;
    break;
  }
}
boolean dead=false;
public void draw() {
  background(0);
  if (dead) {
    x=25;
    y=25;
    _counter =20;
    _delay =5;
    for (int i = 0; i < cols; i++) {
      for (int j = 0; j < rows; j++) {
        grid[i][j].type=0;
        grid[i][j].delay=0;
      }
    }

    dead=false;
  } else {
    doDirection();
    _counter++;
    if (_counter >= 50) {
      int _r = PApplet.parseInt(random(2, 6));
      int _x = PApplet.parseInt( random(cols));
      int _y = PApplet.parseInt( random(rows));
      if ( grid[_x][_y].type!=1) {
        grid[_x][_y].type=_r;
        grid[_x][_y].delay+=_delay*10*_r;
      }
      _counter=0;
      println("Candy ", _r);
    }
    if ((x<0 || x>cols) || (y<0 || y>rows )) {
      dead=true;
    }

    noSmooth();  
    for (int i = 0; i < cols; i++) {
      for (int j = 0; j < rows; j++) {
        // Oscillate and display each object
        //grid[i][j].oscillate();

        if (i==x && j==y) {

          if (grid[i][j].type >0) {

            if (grid[i][j].type==1) {
              println("DEAD");
              dead=true;
            } else {
              println("Hunt ", grid[i][j].type);
              grid[i][j].type=0;
              grid[i][j].delay=0;
              _delay+=5;
            }
          }

          grid[i][j].type=1;
          grid[i][j].delay+=_delay;
        }

        grid[i][j].display();
      }
    }

    textFont(myFont);
    textAlign(CENTER, CENTER);
    fill(255);
    text("SCORE = " + _delay, width/2, height-30);
    //println(x, y, d, _counter);
  }
}

public void keyPressed() {
  if (key == CODED) {
    switch(keyCode) {
    case UP:
      if (d != Direction.DOWN)
        d=Direction.UP;
      break;
    case DOWN:
      if (d != Direction.UP)
        d=Direction.DOWN;
      break;
    case RIGHT:
      if (d != Direction.LEFT)
        d=Direction.RIGHT;
      break;
    case LEFT:      
      if (d != Direction.RIGHT)
        d=Direction.LEFT;
      break;
    }
  }
}

// A Cell object
class Cell {

  int type, delay=0;
  // A cell object knows about its location in the grid 
  // as well as its size with the variables x,y,w,h
  float x, y;   // x,y location
  float w, h;   // width and height
  float angle; // angle for oscillating brightness

  // Cell Constructor
  Cell(float tempX, float tempY, float tempW, float tempH, float tempAngle) {
    x = tempX;
    y = tempY;
    w = tempW;
    h = tempH;
    angle = tempAngle;
  } 

  // Oscillation means increase angle
  public void oscillate() {
    angle += 0.02f;
  }

  public void display() {
    if (delay<=0) {
      type=0;
    } else {
      delay--;
    }

    switch(type) {
    case 0:
      fill(0xffCCCCCC);
      break;
    case 1:
      fill(0xffF0F3F4);
      break;
    case 2:
      fill(0xffF39C12);
      break;
    case 3:
      fill(0xff82E0AA);
      break;
    case 4:
      fill(0xffDC7633);
      break;
    case 5:
      fill(0xff5DADE2);
      break;
    }

    stroke(255);
    // Color calculated using sine wave
    //fill(127+127*sin(angle));
    rect(x, y, w, h);
  }
}
  public void settings() {  size(800, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "snake" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
