import express from 'express';
import path from 'path';
import spinner from '../lib/spinner';

const router = express.Router();

router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname + '/../client/index.html'));
});

router.get('/spin', (req, res) => {
    res.end(JSON.stringify(spinner.spin()));
});

export default router;
