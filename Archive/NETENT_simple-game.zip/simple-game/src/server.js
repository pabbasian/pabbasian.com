import express from 'express';
import routes from './routes/main.routes';
import path from 'path';

const app = express();
app.use('/', routes);
app.use(express.static(path.join(__dirname, 'client')));

const server = app.listen(3000, () => {
	const {address, port} = server.address();
	console.log(`app listening at http://${address}:${port}`);
});
