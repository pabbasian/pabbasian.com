var game;
var helper;
var btnSpin;

function handleRequest(req) {
    var res = JSON.parse(req.response);
    game.draw(res);
    if (res.bonus) {
        btnSpin.className += " inactive";
        setTimeout(function() {
            spin(); //bonus!
            btnSpin.className -= " inactive";
        }, 3000);
    }
}

function spin() {
    helper.sendRequest('/spin', handleRequest);
}

window.onload = function() {
    var el = document.getElementById("canvas");
    btnSpin = document.getElementById('btnSpin');
    game = new Game(el);
    helper = new Helper();
    helper.addEvent(btnSpin, 'click', spin);
};
