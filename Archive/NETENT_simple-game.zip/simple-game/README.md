
# setup
npm install  

# start the server (starts babel-node with nodemon)
npm start 

# open in browser
http://localhost:3000

# build for production (output to dist folder)
npm run build

